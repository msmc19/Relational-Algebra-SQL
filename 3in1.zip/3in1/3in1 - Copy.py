#SIGNED BY AARON MARSHALL

#Justification for the code below

"""
To start, I worked with the most basic concepts I knew by not only
utilizing any code from prior classes, but also directly working with the python refresher
and cheat sheet. Additionally, I utilized the internet for properly creating my
nested for loop. This is the link to the information I took inspiration from:

https://www.geeksforgeeks.org/python-nested-loops/

- Main Function:
Much different than our prior dice roll simulator, I utilized a singular
main() function for all different choices. I wanted to keep it all together in a singular document
rather than multiple programs working at once.

- Coin Flip
For my coin flip, I simply made a list with both "Heads" and "Tails"
as the option utilizing the 'random' library as a way to randomly pick
either heads or tails

- Dice Roll
I asked the user to pick from the 4 options of dice. When the X sided dice
is chosen, that number is stored in the dice variable. The result is then
outputted based on the 'randint' function randomly picking between 1 and the
X side chosen by the user. Ex. User picks 8, then it pick a random integer between 1 and 8.

- Card Draw
I create three list named "suits", "ranks", and "deck." Suits and ranks are
given their respective strings based on the 52 deck properties. The deck list is kept
empty to properly mix and match suits and ranks later.

I started by asking for a user input if the user wants "Jokers" in their deck.
A nested for-loop iterates through each suit (Hearts, Diamonds, Clubs, Spades)
in the suits list. For each suit, it then iterates over each rank (2, 3, 4,...Ace) in the ranks
list. For every combination of suit and rank, a card is created (Ex. "3 of CLubs") and added
to the deck list. If the user says "Yes" to Jokers, two Joker strings are added to the deck list as well.

- Overall organization
The program is designed with a while loop to keep running until the user inputs to allow for ease
of access between all options.



"""


import random

def main():
    while True:
        print("Welcome to the 3in1 App!")
        print("1. Coin Flip")
        print("2. Dice Roll")
        print("3. Draw a card")
        print("4. Close Application")

        choice = input("Pick a choice above: ")

        if choice == "1":
            result = random.choice(["Heads", "Tails"])
            print(f"You flipped {result}!")
        elif choice == "2":
            dice = input("Roll a die [6-sided, 8-sided, 10-sided, or 12-sided]: ")
            if dice in ["6", "8", "10", "12"]:
                result = random.randint(1, int(dice))
                print(f"You rolled a {result} on a {dice}-sided die!")
            else:
                print("Invalid choice.")
        elif choice == "3":
            jokers = input("Would you like to include jokers in the deck? [Y/N]: ")
            ranks = ["2", "3", "4", "5", "6", "7", "8", "9", "Jack", "Queen", "King", "Ace"]
            suits = ["Hearts", "Diamonds", "Clubs", "Spades"]
            deck = []

            #This nested for-loop helps simplify the interation between the ranks and suits list effectively.
            for suit in suits:
                for rank in ranks:
                    deck.append(f"{rank} of {suit}")
            if jokers == "Y":
                #Based on a deck of 52, you add in two jokers
                deck.append("Joker")
                deck.append("Joker")
            result = random.choice(deck)
            print(f"You drew a {result}!")
        elif choice == "4":
            print("Goodbye.")
            break
        else:
            print("Invalid input.")

if __name__ == "__main__":
    main()